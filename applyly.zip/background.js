chrome.runtime.onInstalled.addListener(()=>{console.log("Applyly™ extension installed")});
